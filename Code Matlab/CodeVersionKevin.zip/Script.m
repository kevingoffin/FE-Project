clear; clc;
close all
format long
%% Question A - Optimal Trading Bands Analysis
fprintf('=================================== Question A ===================================\n');
% This section performs the optimization of trading bands for a statistical arbitrage strategy
% using Ornstein-Uhlenbeck (OU) process parameters with stop-loss and transaction costs.
%
% Methodology:
% 1. Takes calibrated OU process parameters (theta, sigma)
% 2. Computes optimal trading bands (d,u) for a range of transaction costs
% 3. Visualizes the relationship between costs and optimal bands
% 4. Demonstrates strategy feasibility under different cost regimes

tic;  % Start timer to measure execution performance

% === OU Process Parameters ===
theta = 0.041;        % Mean-reversion time scale (1/kappa) in years
                      % Indicates spreads revert to mean in ~1/0.041 ≈ 24.4 days
sigma = 0.0147;       % Stationary standard deviation (sigma/sqrt(2*kappa))
                      % Annualized volatility of the spread process
                      % Critical for determining trading band distances

% === Stop-loss Level ===
l = -1.960;           % Stop-loss threshold in standard deviation units
                      % Corresponds to 2.5% one-tailed significance (Z=-1.96)
                      % Chosen to limit downside while allowing mean-reversion

% === Transaction Cost Range ===
c_vals = linspace(0.001, 0.75, 100);  % Range of normalized transaction costs
                                      % Expressed as fractions of sigma
                                      % 0.001: Near frictionless market
                                      % 0.75: Upper practical limit before
                                      % strategy becomes unprofitable

% === Strategy Leverage ===
f = 1;                % Capital allocation factor (1 = 100% invested)
                      % Maintained at 1 for unlevered baseline analysis
                      % Could be increased for leveraged strategies

% === Optimize Trading Bands ===
[d_vals, u_vals] = maximize_mu(c_vals, l, sigma, theta, f);
% Computes:
%   d_vals: Vector of optimal entry points (below mean)
%            where spread is "too low" and likely to revert up
%   u_vals: Vector of optimal exit points (above mean)
%            where spread is "too high" and likely to revert down
% For each c in c_vals, finds (d,u) that maximize expected return μ

% === Visualization ===
flag = true;       % Controls plot display mode
                   % true = basic plot without critical cost markers
                   % false = enhanced plot with profitability thresholds
plot_BANDSvsCOST(c_vals, d_vals, u_vals, flag);
% Generates:
% - Curve of d*(c) showing how entry points vary with costs
% - Curve of u*(c) showing how exit points vary with costs
% - Demonstrates the cost-band tradeoff critical for strategy design

elapsedTimeA = toc;
fprintf('Execution time for Question A: %.4f seconds\n', elapsedTimeA);
% Typical execution times:
% - <1 sec for 100 cost points on modern hardware
% - Scales linearly with number of cost points

%% Question B – Inference from Historical Data (HO-LGO)
fprintf('=================================== Question B ===================================\n');
tic;

% === Step 1: Read Excel file and extract relevant data ===
% Skip the first two header rows to get to the data
opts = detectImportOptions('HO-LGO.xlsm', 'Sheet', 'HO-LGO 30min');
opts.DataRange = 'A3';  % Start from row 3

% Read the data table
T = readtable('HO-LGO.xlsm', opts);

% Define column indices for relevant data:
% column_timestamp = time
% columnHO = [HO Bid, HO Ask], columnLGO = [LGO Bid, LGO Ask]
column_timestamp = 2; 
columnHO = [3, 7]; 
columnLGO = [4, 8];

% Currency converters: HO in $/gallon, LGO in $/barrel
converterHO = 42; 
converterLGO = 20/149;

% Extract midprices and log-returns from bid/ask data
[Rt, timestamp, ~, ~, bid_HO, bid_LGO, ask_HO, ask_LGO] = ...
    extractionBidAskMidLogReturn(T, column_timestamp, columnHO, columnLGO, converterHO, converterLGO, flag);

% === Step 2: Clean Data and Split into IS/OS Periods ===
InputFormat = 'yyyy-MM-dd HH:mm:ss'; 
splitTime = calmonths(9); 
verbose = true;

% Remove statistical outliers from log-returns
[Rt_filtered, time_filtered, index_filtered] = removeOutliers(Rt, timestamp, InputFormat, verbose);

% Split filtered data into In-Sample (IS) and Out-of-Sample (OS)
[Rt_IS_filtered, time_IS_filtered, Rt_OS_filtered, time_OS_filtered] = ...
    IS_OS_split(Rt_filtered, time_filtered, splitTime, verbose);

% === Step 3: In-Sample Calibration for NY Trading Hours 9:00–16:00 ===
flag = true;
verbose = true;
starting_hour = 9;
ending_hour = 16;

% Filter IS data between 9:00 and 16:00
table_IS_Filtered_9_16 = filterTimeWindow(time_IS_filtered, Rt_IS_filtered, starting_hour, ending_hour, flag, verbose);

% Estimate time increment per observation
proportion = computeTimeProportion(timestamp(1), splitTime, timestamp(end));
deltaT = proportion / height(table_IS_Filtered_9_16);

% Extract log-returns for calibration
Rt_9_16 = table2array(table_IS_Filtered_9_16(:, 2));

% Calibrate OU process parameters (η, θ, σ)
[eta_hat, k_hat, sigma_hat] = calibration(Rt_9_16, deltaT);

% === Step 4: Parameter Simulation via Bootstrapping ===
n_sim = 1e2;
rng(42);  % For reproducibility

% Simulate parameter estimates using bootstrap
[sigma_hat_vector, k_hat_vector, eta_hat_vector] = simulation(Rt_9_16, n_sim, deltaT, eta_hat, k_hat, sigma_hat);

% Compute 95% Confidence Intervals for parameters
alpha = 0.05;
ci_k     = prctile(k_hat_vector,     [alpha * 50, 100 - alpha * 50]);
ci_sigma = prctile(sigma_hat_vector, [alpha * 50, 100 - alpha * 50]);
ci_eta   = prctile(eta_hat_vector,   [alpha * 50, 100 - alpha * 50]);

% Print estimated parameters and confidence intervals
print_MLE_CI(k_hat, eta_hat, sigma_hat, alpha, ci_k, ci_sigma, ci_eta, ...
             k_hat_vector, sigma_hat_vector, eta_hat_vector, ...
             starting_hour, ending_hour);

% === Step 5: Repeat Calibration for NY Trading Hours 8:00–16:00 ===
starting_hour = 8; 
ending_hour = 16;

% Filter IS data between 8:00 and 16:00
table_IS_Filtered_8_16 = filterTimeWindow(time_IS_filtered, Rt_IS_filtered, starting_hour, ending_hour, flag, verbose);

% Recalculate deltaT for this time window
proportion = computeTimeProportion(timestamp(1), splitTime, timestamp(end));
deltaT = proportion / height(table_IS_Filtered_8_16);

% Extract log-returns and calibrate OU parameters
Rt_8_16 = table2array(table_IS_Filtered_8_16(:, 2));
[eta_hat, k_hat, sigma_hat] = calibration(Rt_8_16, deltaT);

% Simulate bootstrap distribution of OU parameters
rng(42);  % Same seed for consistency
[sigma_hat_vector, k_hat_vector, eta_hat_vector] = ...
    simulation(Rt_8_16, n_sim, deltaT, eta_hat, k_hat, sigma_hat);

% Compute and print 95% confidence intervals
ci_k     = prctile(k_hat_vector,     [alpha * 50, 100 - alpha * 50]);
ci_sigma = prctile(sigma_hat_vector, [alpha * 50, 100 - alpha * 50]);
ci_eta   = prctile(eta_hat_vector,   [alpha * 50, 100 - alpha * 50]);

print_MLE_CI(k_hat, eta_hat, sigma_hat, alpha, ci_k, ci_sigma, ci_eta, ...
             k_hat_vector, sigma_hat_vector, eta_hat_vector, ...
             starting_hour, ending_hour);

% === Step 6: Final Timing ===
elapsedTimeB = toc;
fprintf('Execution time for Question B: %.4f seconds\n', elapsedTimeB);

%% === Question C: Trading Cost and Strategy Analysis ===
% This section analyzes transaction costs and their impact on the trading strategy,
% including visualization of cost distributions and optimal trading bands.
% -------------------------------------------------------------------------
fprintf('=================================== Question C ===================================\n');
tic;  % Start performance timer

% === 1. Compute Transaction Cost Metrics ===
% Calculate round-trip transaction costs and strategy parameters:
% - C: Raw transaction costs (log ratios)
% - expected_C: Mean transaction cost
% - SIGMA: Annualized stationary volatility (σ/sqrt(2κ))
% - c_bar: Cost normalized by volatility (expected_C/SIGMA)
% - theta: Mean-reversion timescale (1/κ)
[C, expected_C, SIGMA, c_bar, theta] = computeTransactionCost(...
    bid_HO, bid_LGO, ask_HO, ask_LGO, timestamp, ...
    sigma_hat, k_hat, starting_hour, ending_hour, splitTime, index_filtered);

% === 2. Visualize Cost Distribution ===
% Create histogram bins spanning 0 to 45% of volatility (160 bins)
edges = 0:0.0028:0.45;  % 2.8 basis point bin width

figure('Position', [100 100 800 400]);  % Set figure size [width height]

% Plot probability histogram of normalized costs (C/σ)
h = histogram(C./SIGMA, edges, ...
          'Normalization', 'probability', ...  % Show relative frequencies
          'FaceColor', [0.2 0.6 0.8], ...    % Custom blue tone
          'EdgeColor', [0.1 0.3 0.4], ...     % Darker edges for definition
          'FaceAlpha', 0.8);                  % Semi-transparent fill

% === 3. Format Visualization ===
hold on;

% Add vertical line at mean normalized cost
xline(c_bar, 'r-', 'LineWidth', 2, ...
    'Label', sprintf('Mean (%.3f\\sigma)', c_bar), ...
    'LabelOrientation', 'horizontal');

% Add annotations
title('Distribution of Normalized Transaction Costs', ...
      'FontSize', 12, 'FontWeight', 'bold');
xlabel('Transaction Cost (\sigma units)', 'FontSize', 10);
ylabel('Probability', 'FontSize', 10);
grid on;

% Set axis limits to focus on relevant range
xlim([0 0.15]);  % Focus on 0-15% of σ range where most data lies

% Add textbox with key statistics
annotation('textbox', [0.7 0.7 0.2 0.15], ...
           'String', {sprintf('Mean: %.4f\\sigma', c_bar), ...
                      sprintf('Std Dev: %.4f\\sigma', std(C./SIGMA))}, ...
           'FitBoxToText', 'on', ...
           'BackgroundColor', 'white');

% === Performance Metrics ===
fprintf('Mean normalized cost: %.4fσ\n', c_bar);

% === Strategy Parameters ===
% Set stop-loss threshold at -1.96 standard deviations
% (Common choice for 95% confidence interval in normal distributions)
l = -1.96;  % Stop-loss level in volatility units (σ)

% === Transaction Cost Sensitivity Analysis ===
% Define range of normalized transaction costs to evaluate
% (From 0.1% to 75% of volatility, 100 points)
c_vals = linspace(0.001, 0.75, 100);

% Assume full position sizing (f=1 means 100% of capital per trade)
f = 1;

% Compute optimal trading bands (u*, d*) for given parameters
[u_star, d_star] = bands(c_bar, l, SIGMA, theta, f);

% === Visualize Optimal Bands vs Transaction Costs ===
% Plot relationship between costs and trading thresholds
% flag=false: Disables saving the plot to file
plot_BANDSvsCOST(c_vals, d_vals, u_vals, c_bar, d_star, u_star, false)

% === After-Hours Market Analysis ===
% Filter and analyze trading activity during 17:00-20:00 time window
% flag=false: Returns filtered data without plotting 
% verbose=true: Displays filtering statistics
[table_OS_Filtered_17_20] = filterTimeWindow(...
    time_OS_filtered, Rt_OS_filtered, ...
    17, 20, false, true);  % 17:00 to 20:00 time window

% Testing on Out-of-Sample (OS) Dataset
% === 1. Normalize the OS time series using regime-estimated parameters ===
% Subtract long-term mean (eta_hat) and divide by stationary volatility (SIGMA)
X_OS = (table2array(table_OS_Filtered_17_20(:,2)) - eta_hat) / SIGMA;

% === 2. Plot OS signal with optimal trading thresholds ===
plot_XOS(X_OS, d_star, u_star, l);

% === 3. Initialize wealth ===
w0 = 1;

% === 4. Compute max admissible transaction cost from thresholds ===
% This is useful to check whether current cost is within feasible region
[C_max, p_pls, p_mns] = maximum_transaction_cost(d_star, u_star, l);

% === 5. Set trading parameters ===
f = 1;                     % Leverage factor
scaling_factor = 4;        % Number of strategy cycles per year (quarterly strategy)
verbose = false;           % Suppress verbose output

% === 6. Simulate actual trading strategy on OS data ===
% Computes the annualized return of the strategy using historical OS path
ann_return = optimizedReturn(X_OS, d_star, u_star, l, c_bar, SIGMA, f, scaling_factor, w0, verbose);

% === 7. Compute expected theoretical return using the OU model ===
% μ* as derived from the OU-based expected value formula
mu_theoritical = evaluate_mu(d_star, u_star, c_bar, theta, l, SIGMA, f);

% === 8. Print diagnostic metrics ===
% Display hitting probabilities and return estimates for evaluation
fprintf('Probabilities and sum [%.6f, %.6f, %.6f]\n', p_pls, p_mns, p_pls + p_mns);
fprintf('Expected theoretical result over 1 year: %.6f\n', mu_theoritical);
fprintf('Actual transaction cost (normalized): %.6f\n', c_bar);
fprintf('Actual result over 12 months: %.6f\n', ann_return);

elapsedTimeC = toc;
fprintf('Execution time for Question C: %.4f seconds\n', elapsedTimeC);

%% Question D
fprintf('=================================== Question D ===================================\n');
tic;
% === 1. Compute Optimal Leverage ===
% This finds the theoretical leverage that maximizes expected return
opt_lev = optimalLeverage(SIGMA, theta, c_bar, l, 100);  % Grid of 100 points

% === 2. Define Leverage Levels for Evaluation ===
% Try different leverage levels including the optimal one
leverage_levels = [1, 5, 20, 28, opt_lev];  % Test a wide range including edge and optimal

% === 3. Compute Optimal Trading Bands for Each Leverage ===
% Returns upper and lower thresholds for each leverage value
[u_star_vec, d_star_vec] = bands(c_bar, l, SIGMA, theta, leverage_levels);

% === 4. Compute Theoretical Returns ===
% Evaluate μ(f) using analytical expression for OU-based model
% Multiply by 100 to express in annual percentage terms
mu_vector = evaluate_mu(d_star_vec, u_star_vec, c_bar, theta, l, SIGMA, leverage_levels) * 100;

% === 5. Compute Empirical (Simulated) Returns on OS Data ===
% Simulates each strategy using the OS time series
empirical_returns = optimizedReturn(X_OS, d_star_vec, u_star_vec, l, ...
                                    c_bar, SIGMA, leverage_levels, ...
                                    scaling_factor, w0, verbose);

% === 6. Plot Theoretical vs. Empirical Returns vs. Leverage ===
plot_leveragesVSreturns(leverage_levels, empirical_returns, opt_lev, mu_vector);


% === Confidence Interval Computation for Trading Parameters ===% Set confidence level and upper bound for cost grid
alpha = 0.05;               % Significance level for 95% confidence interval
CostUpperBound = 0.75;      % Upper limit for transaction cost search space

% Compute 95% confidence intervals for d*, u*, and μ* 
% using bootstrapped estimates of sigma and kappa
[ci_d, ci_u, ci_mu] = confidenceIntervalAdv(sigma_hat_vector, k_hat_vector, ...
                                            l, expected_C, opt_lev, ...
                                            alpha, CostUpperBound);

% Display the 95% confidence intervals for each parameter
fprintf('=== Confidence intervals for d, u, and mu ===\n');
fprintf('95%% CI for d  : [%.15f, %.15f]\n', ci_d(1), ci_d(2));
fprintf('95%% CI for u  : [%.15f, %.15f]\n', ci_u(1), ci_u(2));
fprintf('95%% CI for mu : [%.15f, %.15f]\n', ci_mu(1), ci_mu(2));

elapsedTimeD = toc;
fprintf('Execution time for Question D: %.4f seconds\n', elapsedTimeD);

%% === E. Impact of Stop-Loss Level (l) on Annualized Return ===
fprintf('=================================== Question E ===================================\n');
tic;
% This section evaluates how changing the stop-loss level `l` affects
% the annualized return of the trading strategy.

% Define a vector of stop-loss thresholds (standard normal quantiles)
l_vector = [-1.282, -1.645, -1.96, -2.326];  % Corresponding to 90%, 95%, 97.5%, 99% confidence levels
length_l_vector = length(l_vector);

% Use fixed leverage
f = 1;

% Preallocate vector to store annualized percentage returns
ann_pct_return_vector = zeros(length_l_vector, 1);

% Loop through each stop-loss level and compute return
for i = 1:length_l_vector
    l = l_vector(i);  % Current stop-loss
    
    % Compute optimal bands for this stop-loss
    [u_star, d_star, ~] = bands(c_bar, l, SIGMA, theta, f);
    
    % Simulate and store the annualized return from the strategy
    ann_pct_return_vector(i) = optimizedReturn(X_OS, d_star, u_star, ...
                                               l, c_bar, SIGMA, ...
                                               f, scaling_factor, ...
                                               w0, verbose);
end

% === Customized Plot 1: Return vs. Stop-Loss Level ===
figure;
plot(l_vector, ann_pct_return_vector, '-o', ...
     'LineWidth', 2, ...
     'MarkerSize', 8, ...
     'MarkerFaceColor', 'b', ...
     'Color', [0.2 0.4 0.8]);

grid on;
grid minor;

xlabel('Stop-loss threshold (l)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Annualized return (%)', 'FontSize', 12, 'FontWeight', 'bold');
title('Effect of Stop-Loss Level on Annualized Return', 'FontSize', 14);

% Annotate data points with l values
for i = 1:length(l_vector)
    text(l_vector(i), ann_pct_return_vector(i) + 0.01, ...
         sprintf('l = %.3f', l_vector(i)), ...
         'FontSize', 10, 'HorizontalAlignment', 'center');
end

xlim([min(l_vector)-0.1, max(l_vector)+0.1]);
ylim([min(ann_pct_return_vector)-0.02, max(ann_pct_return_vector)+0.02]);

set(gca, 'FontSize', 11, 'LineWidth', 1.2);

% === Customized Plot 2: OU Process with Stop-Loss Thresholds ===
figure;
plot(X_OS, 'Color', [0.1 0.1 0.1], 'LineWidth', 1.5); hold on;

% Add each stop-loss threshold with a unique color and label
colors = lines(length(l_vector));
for i = 1:length(l_vector)
    yline(l_vector(i), '--', ...
          'Color', colors(i,:), ...
          'LineWidth', 1.5, ...
          'Label', sprintf('l = %.3f', l_vector(i)), ...
          'LabelHorizontalAlignment', 'left', ...
          'LabelVerticalAlignment', 'middle', ...
          'FontSize', 10);
end

xlabel('Time', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Normalized log-price process', 'FontSize', 12, 'FontWeight', 'bold');
title('Stop-Loss Thresholds on Normalized OU Process', 'FontSize', 14);
grid on; grid minor;

legend(['OU Process', arrayfun(@(x) sprintf('l = %.3f', x), l_vector, 'UniformOutput', false)], ...
       'Location', 'best');

set(gca, 'FontSize', 11, 'LineWidth', 1.2);

elapsedTimeE = toc;
fprintf('Execution time for Question E: %.4f seconds\n', elapsedTimeE);

%% Analysis with the GovernativeFutures dataset
% clear; 
% clc;
% close all
% format long

%% Question G: Futures Pairs Trading Strategy Analysis
% This section analyzes two government futures pairs (IKA/RXA and OATA/OEA) 
% through: calibration, simulation, optimal band calculation, and performance testing
% -------------------------------------------------------------------------
fprintf('=================================== Question G ===================================\n');
tic;  % Start execution timer

% 1. Data Import and Preparation
% Read Excel file containing futures data (skip header row)
opts = detectImportOptions('GovernativeFutures.xlsx', 'Sheet', 'sheet1');
opts.DataRange = 'A2'; % Start from row 2 to skip headers
T = readtable('GovernativeFutures.xlsx', opts);

fprintf('*********************************** IXA/RXA ***********************************\n');
% Extract IKA/RXA pair data
column_timestamp = 1; columnIKA = 2; columnRXA = 5; 
converterIKA = 1; converterRXA = 1; flag = false;
[Rt_IKA_RXA, timestamp, mid_IKA, mid_RXA, ~, ~, ~, ~] = ...
    extractionBidAskMidLogReturn(T, column_timestamp, columnIKA, columnRXA, converterIKA, converterRXA, flag);

% 2. Data Cleaning and Splitting
InputFormat = 'yyyy-MM-dd HH:mm:ss'; 
splitTime = calmonths(4); % Split into 4-month periods
verbose = true;

% Process IKA/RXA pair
[Rt_IKA_RXA_filtered, time_IKA_RXA, index_IKA_RXA_filtered] = ...
    removeOutliers(Rt_IKA_RXA, timestamp, InputFormat, verbose);
[Rt_IKA_RXA_IS, time_IKA_RXA_IS, Rt_IKA_RXA_OS, time_IKA_RXA_OS] = ...
    IS_OS_split(Rt_IKA_RXA_filtered, time_IKA_RXA, splitTime, verbose);

% 3. Intraday Filtering (8:00-16:00)
flag = true; verbose = true; 
starting_hour = 8; ending_hour = 16; % Trading hours
[table_IS_IKA_RXA_8_16] = filterTimeWindow(time_IKA_RXA_IS, Rt_IKA_RXA_IS, starting_hour, ending_hour, flag, verbose);

% 4. Model Calibration
% Calculate time proportion for proper scaling
proportion = computeTimeProportion(timestamp(1), splitTime, timestamp(end));
deltaT_IKA_RXA = proportion/height(table_IS_IKA_RXA_8_16); 
Rt_IKA_RXA = table2array(table_IS_IKA_RXA_8_16(:, 2));
[eta_hat_IKA_RXA, k_hat_IKA_RXA, sigma_hat_IKA_RXA] = calibration(Rt_IKA_RXA, deltaT_IKA_RXA);

% 5. Monte Carlo Simulation
n_sim = 1e2; % Number of simulations
rng(42); % Set random seed for reproducibility
[sigma_hat_IKA_RXA_sim, k_hat_IKA_RXA_sim, eta_hat_IKA_RXA_sim] = simulation(Rt_IKA_RXA, n_sim, deltaT_IKA_RXA, eta_hat_IKA_RXA, k_hat_IKA_RXA, sigma_hat_IKA_RXA);

% 6. Confidence Intervals (95%)
alpha = 0.05;
start_hour = 8; end_hour = 16;
ci_k_IKA_RXA = prctile(k_hat_IKA_RXA_sim, [alpha * 50, 100 - alpha * 50]);
ci_sigma_IKA_RXA = prctile(sigma_hat_IKA_RXA_sim, [alpha * 50, 100 - alpha * 50]);
ci_eta_IKA_RXA = prctile(eta_hat_IKA_RXA_sim, [alpha * 50, 100 - alpha * 50]);

% Print results
fprintf('===Parameters for IKA/RXA===\n');
print_MLE_CI(k_hat_IKA_RXA, eta_hat_IKA_RXA, sigma_hat_IKA_RXA, alpha, ...
             ci_k_IKA_RXA, ci_sigma_IKA_RXA, ci_eta_IKA_RXA, ...
             k_hat_IKA_RXA_sim, sigma_hat_IKA_RXA_sim, eta_hat_IKA_RXA_sim, ...
             start_hour, end_hour);

% 7. Optimal Trading Strategy
l = -1.960; % 2.5% quantile stop-loss
f = 1; % No leverage
c_vals = linspace(0.001, 1.00, 100); % Cost range
bidAskSpread = 0.01; % 1% spread
[d_vals_RXA_IKA, u_vals_RXA_IKA, d_star_RXA_IKA, u_star_RXA_IKA, ...
 c_bar_RXA_IKA, SIGMA_RXA_IKA, theta_RXA_IKA, expected_C_RXA_IKA] = ...
    optimizedTradingStrategy(mid_RXA, mid_IKA, sigma_hat_IKA_RXA, k_hat_IKA_RXA, ...
                            l, f, c_vals, bidAskSpread);

% 8. Strategy Visualization
% IKA/RXA Band Plot
figure('Position', [100 100 800 400]);
plot(c_vals, -d_vals_RXA_IKA, 'r-', 'LineWidth', 1.5); 
hold on;
plot(c_vals, u_vals_RXA_IKA, 'b--', 'LineWidth', 1.5);
xline(c_bar_RXA_IKA, 'g--', 'LineWidth', 1.5, 'Label', 'c_{bar}');
plot([c_bar_RXA_IKA, c_bar_RXA_IKA], [-d_star_RXA_IKA, u_star_RXA_IKA], ...
     'o', 'MarkerEdgeColor','c','MarkerFaceColor','c','MarkerSize',8);
xlabel('Transaction Cost (c) in \sigma units');
ylabel('Optimal Trading Bands');
legend('|d^*| (Entry)', 'u^* (Exit)', 'Location', 'NorthWest');
title('IKA/RXA: Optimal Trading Bands vs Transaction Cost');
grid on;
set(gca, 'FontSize', 10);

% 9. Out-of-Sample Testing (17:00-20:00)
flag = false; verbose = true; 
starting_hour = 17; ending_hour = 20; % After-hours period
[table_IKA_RXA_OS] = filterTimeWindow(time_IKA_RXA_OS, Rt_IKA_RXA_OS, starting_hour, ending_hour, flag, verbose);

% Prepare returns calculation
scaling_factor = 6; w0 = 1; verbose = true; verbose_optimizedReturned = false;
Rt_IKA_RXA_OS_17_20 = table2array(table_IKA_RXA_OS(:,2));
[X_OS_IKA_RXA, value_IKA_RXA, ~] = long_run_futures(Rt_IKA_RXA_OS_17_20, ...
    eta_hat_IKA_RXA, theta_RXA_IKA, SIGMA_RXA_IKA, u_star_RXA_IKA, d_star_RXA_IKA, ...
    l, c_bar_RXA_IKA, f, w0, scaling_factor, verbose, verbose_optimizedReturned);

% 10. Leverage Analysis
f_max = 20; % Maximum leverage to test
f = [1, 5, 10, 28, 35, 50, 65, 75, 90, 120, 0]; % Specific leverage levels
scaling_factor = 6; w0 = 1; 
verbose_optimizeReturn = false; alpha = 0.01;
[opt_lev_IKA_RXA, rtn_IKA_RXA, mu_vector_IKA_RXA] = ...
    run_leverage(X_OS_IKA_RXA, SIGMA_RXA_IKA, theta_RXA_IKA, c_bar_RXA_IKA, l, ...
                f_max, sigma_hat_IKA_RXA_sim, k_hat_IKA_RXA_sim, expected_C_RXA_IKA, ...
                d_star_RXA_IKA, u_star_RXA_IKA, value_IKA_RXA, f, w0, scaling_factor, ...
                verbose_optimizeReturn, alpha);

% 11. Stop-Loss Sensitivity Analysis
l_vector = [-1.282, -1.645, -1.96, -2.326]; % Various stop-loss levels (10% to 1% tails)
f = 1; scaling_factor = 6; w0 = 1; 
verbose_optimizedReturned = false;
[ann_return_IKA_RXA] = run_stop_loss(X_OS_IKA_RXA, c_bar_RXA_IKA, SIGMA_RXA_IKA, ...
                                    theta_RXA_IKA, l_vector, f, scaling_factor, w0, ...
                                    verbose_optimizedReturned);

fprintf('*********************************** OATA/OEA ***********************************\n');

% Extract OATA/OEA pair data  
columnOATA = 3; columnOEA = 4; 
converterOATA = 1; converterOEA = 1;
[Rt_OATA_OEA, ~, mid_OATA, mid_OEA, ~, ~, ~, ~] = ...
    extractionBidAskMidLogReturn(T, column_timestamp, columnOATA, columnOEA, converterOATA, converterOEA, flag);

% 2. Data Cleaning and Splitting
InputFormat = 'yyyy-MM-dd HH:mm:ss'; 
splitTime = calmonths(4); % Split into 4-month periods
verbose = true;

% Process OATA/OEA pair  
[Rt_OATA_OEA_filtered, time_OATA_OEA, index_OATA_OEA] = ...
    removeOutliers(Rt_OATA_OEA, timestamp, InputFormat, verbose);
[Rt_OATA_OEA_IS, time_OATA_OEA_IS, Rt_OATA_OEA_OS, time_OATA_OEA_OS] = ...
    IS_OS_split(Rt_OATA_OEA_filtered, time_OATA_OEA, splitTime, verbose);

% 3. Intraday Filtering (8:00-16:00)
flag = true; verbose = true; 
starting_hour = 8; ending_hour = 16; % Trading hours
[table_IS_OATA_OEA_8_16] = filterTimeWindow(time_OATA_OEA_IS, Rt_OATA_OEA_IS, starting_hour, ending_hour, flag, verbose);

% 4. Model Calibration
% Calculate time proportion for proper scaling
proportion = computeTimeProportion(timestamp(1), splitTime, timestamp(end));
deltaT_OATA_OEA = proportion/height(table_IS_OATA_OEA_8_16); 
Rt_OATA_OEA = table2array(table_IS_OATA_OEA_8_16(:, 2));
[eta_hat_OATA_OEA, k_hat_OATA_OEA, sigma_hat_OATA_OEA] = calibration(Rt_OATA_OEA, deltaT_OATA_OEA);

% 5. Monte Carlo Simulation
n_sim = 1e2; % Number of simulations
rng(42); % Set random seed for reproducibility
[sigma_hat_OATA_OEA_sim, k_hat_OATA_OEA_sim, eta_hat_OATA_OEA_sim] = ...
    simulation(Rt_OATA_OEA, n_sim, deltaT_OATA_OEA, eta_hat_OATA_OEA, k_hat_OATA_OEA, sigma_hat_OATA_OEA);

% 6. Confidence Intervals (95%)
alpha = 0.05;
start_hour = 8; end_hour = 16;

% Calculate CIs for OATA/OEA
ci_k_OATA_OEA = prctile(k_hat_OATA_OEA_sim, [alpha * 50, 100 - alpha * 50]);
ci_sigma_OATA_OEA = prctile(sigma_hat_OATA_OEA_sim, [alpha * 50, 100 - alpha * 50]);
ci_eta_OATA_OEA = prctile(eta_hat_OATA_OEA_sim, [alpha * 50, 100 - alpha * 50]);

% Print results
fprintf('===Parameters for OATA/OEA===\n');
print_MLE_CI(k_hat_OATA_OEA, eta_hat_OATA_OEA, sigma_hat_OATA_OEA, alpha, ...
             ci_k_OATA_OEA, ci_sigma_OATA_OEA, ci_eta_OATA_OEA, ...
             k_hat_OATA_OEA_sim, sigma_hat_OATA_OEA_sim, eta_hat_OATA_OEA_sim, ...
             start_hour, end_hour);

% 7. Optimal Trading Strategy
l = -1.960; % 2.5% quantile stop-loss
f = 1; % No leverage
c_vals = linspace(0.001, 1.00, 100); % Cost range
bidAskSpread = 0.01; % 1% spread

% Optimize OATA/OEA strategy
[d_vals_OATA_OEA, u_vals_OATA_OEA, d_star_OATA_OEA, u_star_OATA_OEA, ...
 c_bar_OATA_OEA, SIGMA_OATA_OEA, theta_OATA_OEA, expected_C_OATA_OEA] = ...
    optimizedTradingStrategy(mid_OATA, mid_OEA, sigma_hat_OATA_OEA, k_hat_OATA_OEA, ...
                            l, f, c_vals, bidAskSpread);

% 8. Strategy Visualization
% OATA/OEA Band Plot
figure('Position', [100 100 800 400]);
plot(c_vals, -d_vals_OATA_OEA, 'r-', 'LineWidth', 1.5); 
hold on;
plot(c_vals, u_vals_OATA_OEA, 'b--', 'LineWidth', 1.5);
xline(c_bar_OATA_OEA, 'g--', 'LineWidth', 1.5, 'Label', 'c_{bar}');
plot([c_bar_OATA_OEA, c_bar_OATA_OEA], [-d_star_OATA_OEA, u_star_OATA_OEA], ...
     'o', 'MarkerEdgeColor','c','MarkerFaceColor','c','MarkerSize',8);
xlabel('Transaction Cost (c) in \sigma units');
ylabel('Optimal Trading Bands');
legend('|d^*| (Entry)', 'u^* (Exit)', 'Location', 'NorthWest');
title('OATA/OEA: Optimal Trading Bands vs Transaction Cost');
grid on;
set(gca, 'FontSize', 10);

% 9. Out-of-Sample Testing (17:00-20:00)
flag = false; verbose = true; 
starting_hour = 17; ending_hour = 20; % After-hours period
[table_OATA_OEA_OS] = filterTimeWindow(time_OATA_OEA_OS, Rt_OATA_OEA_OS, starting_hour, ending_hour, flag, verbose);

% Prepare returns calculation
scaling_factor = 6; w0 = 1; verbose = true; verbose_optimizedReturned = false;

% Calculate OS performance
Rt_OATA_OEA_OS_17_20 = table2array(table_OATA_OEA_OS(:,2));
[X_OS_OATA_OEA, value_OATA_OEA, ~] = long_run_futures(Rt_OATA_OEA_OS_17_20, ...
    eta_hat_OATA_OEA, theta_OATA_OEA, SIGMA_OATA_OEA, u_star_OATA_OEA, d_star_OATA_OEA, ...
    l, c_bar_OATA_OEA, f, w0, scaling_factor, verbose, verbose_optimizedReturned);

% 10. Leverage Analysis
f_max = 20; % Maximum leverage to test
f = [1, 5, 10, 28, 35, 50, 65, 75, 90, 120, 0]; % Specific leverage levels
scaling_factor = 6; w0 = 1; 
verbose_optimizeReturn = false; alpha = 0.01;    
[opt_lev_OATA_OEA, rtn_OATA_OEA, mu_vector_OATA_OEA] = ...
    run_leverage(X_OS_OATA_OEA, SIGMA_OATA_OEA, theta_OATA_OEA, c_bar_OATA_OEA, l, ...
                f_max, sigma_hat_OATA_OEA_sim, k_hat_OATA_OEA_sim, expected_C_OATA_OEA, ...
                d_star_OATA_OEA, u_star_OATA_OEA, value_OATA_OEA, f, scaling_factor, w0, ...
                verbose_optimizeReturn, alpha);

% 11. Stop-Loss Sensitivity Analysis
l_vector = [-1.282, -1.645, -1.96, -2.326]; % Various stop-loss levels (10% to 1% tails)
f = 1; scaling_factor = 6; w0 = 1; 
verbose_optimizedReturned = false;                             
[ann_return_OATA_OEA] = run_stop_loss(X_OS_OATA_OEA, c_bar_OATA_OEA, SIGMA_OATA_OEA, ...
                                     theta_OATA_OEA, l_vector, f, scaling_factor, w0, ...
                                     verbose_optimizedReturned);

% Final Output
elapsedTimeG = toc;
fprintf('\n=== Execution Summary ===\n');
fprintf('Total execution time question G: %.4f seconds\n', elapsedTimeG);
fprintf('IKA/RXA optimal leverage: %.1fx\n', opt_lev_IKA_RXA);
fprintf('OATA/OEA optimal leverage: %.1fx\n', opt_lev_OATA_OEA);
fprintf('IKA/RXA best stop-loss: %.3fσ\n', l_vector(ann_return_IKA_RXA == max(ann_return_IKA_RXA)));
fprintf('OATA/OEA best stop-loss: %.3fσ\n', l_vector(ann_return_OATA_OEA == max(ann_return_OATA_OEA)));

%% Analysis with the Coca-cola VS Pepsi dataset
% clear; 
% clc;
% close all;
% format long

%% Question H: Energy Sector Pairs Trading Strategy (XLE vs XOP)
% This section analyzes a pairs trading strategy between XLE (Energy Select Sector SPDR) 
% and XOP (SPDR S&P Oil & Gas Exploration & Production ETF) using:
% 1. OU process calibration
% 2. Bootstrap confidence intervals
% 3. Optimal trading band calculation
% 4. Out-of-sample performance testing
% -------------------------------------------------------------------------

% 1. Data Import and Preparation
fprintf('=================================== Question H ===================================\n');
tic;
% Import Excel data with custom options
opts = detectImportOptions('KO_PEP.xlsx', 'Sheet', 'KO');
opts.DataRange = 'A4'; % Skip first 3 header rows, start from row 4
T = readtable('KO_PEP.xlsx', opts);

% Define data columns (timestamp, bid/ask pairs)
column_timestamp = 1;      % Column containing timestamps
columnXLE = [4, 3];        % XLE [Bid, Ask] columns  
columnXOP = [10, 9];       % XOP [Bid, Ask] columns

% Currency conversion factors (adjust for price scale differences)
converterXLE = 1;          % No conversion needed for XLE
converterXOP = 0.5;        % Adjust XOP prices by 50%
flag = true;               % Enable verbose output during extraction

% Extract mid-prices and log-returns from bid/ask data
[Rt, timestamp, mid_XLE, mid_XOP, low_XLE, low_XOP, high_XLE, high_XOP] = ...
    extractionBidAskMidLogReturn(T, column_timestamp, columnXLE, columnXOP, ...
                                converterXLE, converterXOP, flag);

% 2. Data Cleaning and Period Splitting
InputFormat = 'yyyy-MM-dd HH:mm:ss'; 
splitTime = calmonths(45); % 45-month in-sample period (~3.75 years)
verbose = true;            % Show processing details

% Remove outliers from log-returns using IQR method
[Rt_filtered, time_filtered, ~] = removeOutliers(Rt, timestamp, InputFormat, verbose);

% Split into in-sample (IS) and out-of-sample (OS) periods
[Rt_IS_filtered, ~, Rt_OS_filtered, ~] = ...
    IS_OS_split(Rt_filtered, time_filtered, splitTime, verbose);

% 3. OU Process Calibration
% Calculate time increment between observations (in years)
proportion = computeTimeProportion(timestamp(1), splitTime, timestamp(end));
deltaT = proportion / length(Rt_IS_filtered); 

% Calibrate OU parameters (η, κ, σ) using maximum likelihood
[eta_hat, k_hat, sigma_hat] = calibration(Rt_IS_filtered, deltaT);

% 4. Parameter Uncertainty Analysis
n_sim = 1e2;       % Number of bootstrap simulations
rng(42);           % Set random seed for reproducibility

% Generate bootstrap distributions of parameters
[sigma_hat_vector, k_hat_vector, eta_hat_vector] = ...
    simulation(Rt_IS_filtered, n_sim, deltaT, eta_hat, k_hat, sigma_hat);

% Calculate 95% confidence intervals
alpha = 0.05;
ci_k = prctile(k_hat_vector, [alpha*50, 100-alpha*50]);
ci_sigma = prctile(sigma_hat_vector, [alpha*50, 100-alpha*50]);
ci_eta = prctile(eta_hat_vector, [alpha*50, 100-alpha*50]);

% 5. Parameter Distribution Visualization
% Create consistent figure style
figOpts = {'Color', 'white', 'Position', [100 100 800 400]};
fontOpts = {'FontSize', 11, 'FontWeight', 'bold'};
lineOpts = {'LineWidth', 2, 'Color', 'r'};

% k_hat distribution
figure(figOpts{:});
histogram(k_hat_vector, 100, 'Normalization', 'pdf', ...
          'FaceColor', [0.3 0.6 0.9], 'EdgeColor', 'none');
hold on;
xline(ci_k(1), lineOpts{:}, 'Label', sprintf('%2.1f%%', alpha*50), ...
    'LabelHorizontalAlignment', 'left');
xline(ci_k(2), lineOpts{:}, 'Label', sprintf('%2.1f%%', 100-alpha*50), ...
    'LabelHorizontalAlignment', 'right');
title('Distribution of Mean-Reversion Rate (\kappa)', fontOpts{:});
xlabel('\kappa (1/year)'); ylabel('Probability Density');
grid on; box off;

% sigma_hat distribution
figure(figOpts{:});
histogram(sigma_hat_vector, 100, 'Normalization', 'pdf', ...
          'FaceColor', [0.9 0.5 0.2], 'EdgeColor', 'none');
hold on;
xline(ci_sigma(1), lineOpts{:});
xline(ci_sigma(2), lineOpts{:});
title('Distribution of Volatility (\sigma)', fontOpts{:});
xlabel('\sigma (annualized)'); ylabel('Probability Density');
grid on; box off;

% eta_hat distribution
figure(figOpts{:});
histogram(eta_hat_vector, 100, 'Normalization', 'pdf', ...
          'FaceColor', [0.4 0.8 0.4], 'EdgeColor', 'none');
hold on;
xline(ci_eta(1), lineOpts{:});
xline(ci_eta(2), lineOpts{:});
title('Distribution of Long-Term Mean (\eta)', fontOpts{:});
xlabel('\eta (log-return units)'); ylabel('Probability Density');
grid on; box off;

% 6. Print Calibration Results
fprintf('=== Maximum Likelihood Estimates ===\n');
fprintf('%-12s: %.6f (1/year)\n', 'κ (kappa)', k_hat);
fprintf('%-12s: %.6f\n', 'η (eta)', eta_hat);
fprintf('%-12s: %.6f\n\n', 'σ (sigma)', sigma_hat);

fprintf('=== 95%% Confidence Intervals ===\n');
fprintf('%-12s: [%.6f, %.6f]\n', 'κ interval', ci_k(1), ci_k(2));
fprintf('%-12s: [%.6f, %.6f]\n', 'η interval', ci_eta(1), ci_eta(2));
fprintf('%-12s: [%.6f, %.6f]\n', 'σ interval', ci_sigma(1), ci_sigma(2));

% 7. Optimal Trading Strategy
f = 1;          % No leverage
l = -1.960;     % 2.5% quantile stop-loss 
c_vals = linspace(0.001, 1.00, 100); % Transaction cost range
bidAskSpread = 0.01; % 1% average bid-ask spread

% Calculate optimal trading bands
[d_vals, u_vals, d_star, u_star, c_bar, SIGMA, theta, expected_C] = ...
    optimizedTradingStrategy(mid_XLE, mid_XOP, sigma_hat, k_hat, ...
                            l, f, c_vals, bidAskSpread);

% 8. Trading Band Visualization
figure(figOpts{:});
plot(c_vals, -d_vals, 'r-', 'LineWidth', 2); 
hold on;
plot(c_vals, u_vals, 'b--', 'LineWidth', 2);
xline(c_bar, 'g:', 'LineWidth', 2.5, 'Label', sprintf('c_{bar} = %.3f', c_bar));

% Mark optimal point
plot([c_bar, c_bar], [-d_star, u_star], 'o', ...
     'MarkerSize', 10, 'MarkerFaceColor', [0 0.8 0.8], ...
     'MarkerEdgeColor', 'k');

% Formatting
xlabel('Transaction Cost (c) in σ units', 'FontSize', 11);
ylabel('Optimal Trading Bands (σ units)', 'FontSize', 11);
title('Optimal Trading Bands vs. Transaction Cost', fontOpts{:});
legend({'|d^*| (Entry Band)', 'u^* (Exit Band)'}, 'Location', 'northwest');
grid on;
set(gca, 'Layer', 'top');

% 9. Out-of-Sample Performance
n = 1;                  % No annualization 
w0 = 1;                 % Initial wealth = 1
scaling_factor = 1;     % Return scaling
verbose = true;         % Show detailed output
verbose_optimizedReturned = false; % Suppress optimization details

% Test strategy on out-of-sample data
[X_OS, mu_theoritical, ann_pct_return] = ...
    long_run_futures(Rt_OS_filtered, eta_hat, theta, SIGMA, ...
                    u_star, d_star, l, c_bar, f, w0, scaling_factor, ...
                    verbose, verbose_optimizedReturned);

elapsedTimeH = toc;
fprintf('\n=== Out-of-Sample Performance ===\n');
fprintf('Expected Annual Return: %.2f%%\n', mu_theoritical*100);
fprintf('Realized Return: %.2f%%\n', ann_pct_return*100);
fprintf('Total execution time question H: %.4f seconds\n\n', elapsedTimeH);
fprintf('Total execution time for the all code: %.4f seconds\t%.4f minutes\t%.4f hours\n\n', elapsedTimeA + elapsedTimeB + elapsedTimeC + elapsedTimeD + elapsedTimeE + elapsedTimeG, (elapsedTimeA + elapsedTimeB + elapsedTimeC + elapsedTimeD + elapsedTimeE + elapsedTimeG)/60, (elapsedTimeA + elapsedTimeB + elapsedTimeC + elapsedTimeD + elapsedTimeE + elapsedTimeG)/3600);